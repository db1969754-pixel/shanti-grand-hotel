require("dotenv").config();
const express=require("express");
const path=require("path");
const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
const Database=require("better-sqlite3");
const crypto=require("crypto");

const app=express();
const PORT=process.env.PORT||3000;
const JWT_SECRET=process.env.JWT_SECRET||"change-this-in-production";
const ADMIN_EMAIL=process.env.ADMIN_EMAIL||"admin@royalgrandhotel.com";
const ADMIN_PASSWORD=process.env.ADMIN_PASSWORD||"ChangeMe123!";

const db=new Database(process.env.DB_PATH||path.join(__dirname,"hotel.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,email TEXT UNIQUE,phone TEXT,password_hash TEXT,
 is_guest INTEGER DEFAULT 0,is_admin INTEGER DEFAULT 0,created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS rooms(
 id INTEGER PRIMARY KEY AUTOINCREMENT,number INTEGER UNIQUE NOT NULL,name TEXT NOT NULL,
 type TEXT NOT NULL,price INTEGER NOT NULL,capacity INTEGER NOT NULL,image TEXT NOT NULL,description TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS bookings(
 id INTEGER PRIMARY KEY AUTOINCREMENT,booking_code TEXT UNIQUE NOT NULL,user_id INTEGER NOT NULL,
 room_id INTEGER NOT NULL,guest_name TEXT NOT NULL,guest_phone TEXT NOT NULL,email TEXT NOT NULL,
 guests INTEGER NOT NULL,check_in TEXT NOT NULL,check_out TEXT NOT NULL,notes TEXT,payment_method TEXT NOT NULL,
 total INTEGER NOT NULL,status TEXT DEFAULT 'confirmed',created_at TEXT NOT NULL,
 FOREIGN KEY(user_id) REFERENCES users(id),FOREIGN KEY(room_id) REFERENCES rooms(id)
);
CREATE TABLE IF NOT EXISTS foods(
 id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,category TEXT NOT NULL,price INTEGER NOT NULL,image TEXT NOT NULL,description TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS cart_items(
 id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,food_id INTEGER NOT NULL,quantity INTEGER NOT NULL,
 UNIQUE(user_id,food_id),FOREIGN KEY(user_id) REFERENCES users(id),FOREIGN KEY(food_id) REFERENCES foods(id)
);
CREATE TABLE IF NOT EXISTS food_orders(
 id INTEGER PRIMARY KEY AUTOINCREMENT,order_code TEXT UNIQUE NOT NULL,user_id INTEGER NOT NULL,name TEXT NOT NULL,phone TEXT NOT NULL,room TEXT,notes TEXT,total INTEGER NOT NULL,created_at TEXT NOT NULL,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS food_order_items(
 id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER NOT NULL,food_id INTEGER NOT NULL,name TEXT NOT NULL,price INTEGER NOT NULL,quantity INTEGER NOT NULL,
 FOREIGN KEY(order_id) REFERENCES food_orders(id)
);
CREATE TABLE IF NOT EXISTS service_requests(
 id INTEGER PRIMARY KEY AUTOINCREMENT,request_code TEXT UNIQUE NOT NULL,user_id INTEGER NOT NULL,service TEXT NOT NULL,details TEXT,created_at TEXT NOT NULL,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
`);

function seed(){
  const roomCount=db.prepare("SELECT COUNT(*) c FROM rooms").get().c;
  if(!roomCount){
    const ins=db.prepare("INSERT INTO rooms(number,name,type,price,capacity,image,description) VALUES(?,?,?,?,?,?,?)");
    const types=["Deluxe","Executive","Suite","Family","Presidential"];
    const tx=db.transaction(()=>{
      for(let i=1;i<=56;i++){
        const type=types[(i-1)%types.length];
        const price={Deluxe:3500,Executive:5000,Suite:7500,Family:6500,Presidential:12000}[type]+((i-1)%4)*250;
        const name=`${type} Room ${i}`;
        const image=`https://loremflickr.com/900/650/hotel,${type.toLowerCase()},room?lock=${1000+i}`;
        ins.run(100+i,name,type,price,type==="Family"?4:type==="Presidential"?5:2,image,`Comfortable ${type.toLowerCase()} accommodation with modern amenities.`);
      }
    });tx();
  }
  const foodCount=db.prepare("SELECT COUNT(*) c FROM foods").get().c;
  if(!foodCount){
    const base=[
      ["Masala Dosa","Breakfast",180],["Idli Sambar","Breakfast",140],["Poha","Breakfast",120],["Aloo Paratha","Breakfast",160],["Veg Sandwich","Breakfast",170],
      ["Paneer Tikka","Indian",320],["Butter Chicken","Indian",420],["Dal Makhani","Indian",300],["Palak Paneer","Indian",320],["Chole Bhature","Indian",220],
      ["Veg Hakka Noodles","Chinese",260],["Chicken Fried Rice","Chinese",330],["Manchurian","Chinese",240],["Chilli Paneer","Chinese",290],["Spring Rolls","Chinese",220],
      ["Margherita Pizza","Pizza",380],["Farmhouse Pizza","Pizza",450],["Chicken Pizza","Pizza",520],["Paneer Pizza","Pizza",470],["Four Cheese Pizza","Pizza",550],
      ["Classic Burger","Burger",280],["Chicken Burger","Burger",340],["Cheese Burger","Burger",320],["Veg Burger","Burger",260],["Double Patty Burger","Burger",390],
      ["Chicken Biryani","Biryani",420],["Mutton Biryani","Biryani",520],["Veg Biryani","Biryani",320],["Egg Biryani","Biryani",350],["Hyderabadi Biryani","Biryani",460],
      ["Pasta Alfredo","Continental",390],["Pasta Arrabbiata","Continental",360],["Grilled Chicken","Continental",520],["Veg Lasagna","Continental",420],["Fish and Chips","Continental",480],
      ["Gulab Jamun","Dessert",140],["Chocolate Brownie","Dessert",190],["Cheesecake","Dessert",260],["Ice Cream Sundae","Dessert",220],["Fruit Platter","Dessert",240],
      ["Masala Chai","Beverage",90],["Cappuccino","Beverage",180],["Fresh Lime Soda","Beverage",120],["Mango Shake","Beverage",180],["Mineral Water","Beverage",60],
      ["French Fries","Snacks",160],["Nachos","Snacks",220],["Paneer Roll","Snacks",210],["Chicken Wings","Snacks",320],["Club Sandwich","Snacks",290]
    ];
    const ins=db.prepare("INSERT INTO foods(name,category,price,image,description) VALUES(?,?,?,?,?)");
    const tx=db.transaction(()=>{
      for(let i=0;i<400;i++){
        const b=base[i%base.length], suffix=i<base.length?"":` Special ${Math.floor(i/base.length)+1}`;
        const name=b[0]+suffix;
        const category=b[1],price=b[2]+((i*17)%80);
        const query=encodeURIComponent(b[0].toLowerCase().replace(/[^a-z ]/g,""));
        const image=`https://loremflickr.com/800/600/${query}?lock=${2000+i}`;
        ins.run(name,category,price,image,`Freshly prepared ${b[0].toLowerCase()} from our hotel kitchen.`);
      }
    });tx();
  }
  const admin=db.prepare("SELECT id FROM users WHERE email=?").get(ADMIN_EMAIL);
  if(!admin){
    db.prepare("INSERT INTO users(name,email,phone,password_hash,is_admin,created_at) VALUES(?,?,?,?,1,?)").run("Hotel Admin",ADMIN_EMAIL,"",bcrypt.hashSync(ADMIN_PASSWORD,10),new Date().toISOString());
  }
}
seed();

app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(__dirname,"public")));

function tokenFor(user){return jwt.sign({id:user.id},JWT_SECRET,{expiresIn:"7d"})}
function setCookie(res,token){res.setHeader("Set-Cookie",`hotel_token=${token}; HttpOnly; Path=/; SameSite=Lax; Max-Age=604800${process.env.NODE_ENV==="production"?"; Secure":""}`)}
function clearCookie(res){res.setHeader("Set-Cookie","hotel_token=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax")}
function parseCookies(req){const c={};(req.headers.cookie||"").split(";").forEach(x=>{const [k,...v]=x.trim().split("=");if(k)c[k]=decodeURIComponent(v.join("="))});return c}
function auth(req,res,next){try{const p=jwt.verify(parseCookies(req).hotel_token,JWT_SECRET);const u=db.prepare("SELECT id,name,email,phone,is_guest,is_admin FROM users WHERE id=?").get(p.id);if(!u)return res.status(401).json({error:"Not logged in"});req.user=u;next()}catch{return res.status(401).json({error:"Not logged in"})}}
function admin(req,res,next){auth(req,res,()=>req.user.is_admin?next():res.status(403).json({error:"Admin only"}))}
function code(prefix){return prefix+"-"+crypto.randomBytes(4).toString("hex").toUpperCase()}

app.post("/api/auth/register",(req,res)=>{
  const {name,email,phone,password}=req.body||{};
  if(!name||!email||!phone||!password||password.length<6)return res.status(400).json({error:"Complete all fields; password must be 6+ characters."});
  try{
    const hash=bcrypt.hashSync(password,10);
    const info=db.prepare("INSERT INTO users(name,email,phone,password_hash,created_at) VALUES(?,?,?,?,?)").run(name,email.toLowerCase(),phone,hash,new Date().toISOString());
    const u=db.prepare("SELECT id,name,email,phone,is_guest,is_admin FROM users WHERE id=?").get(info.lastInsertRowid);setCookie(res,tokenFor(u));res.json({user:u});
  }catch(e){res.status(400).json({error:"Email is already registered."})}
});
app.post("/api/auth/login",(req,res)=>{
  const {email,password}=req.body||{};const u=db.prepare("SELECT * FROM users WHERE email=?").get((email||"").toLowerCase());
  if(!u||!u.password_hash||!bcrypt.compareSync(password||"",u.password_hash))return res.status(401).json({error:"Invalid email or password."});
  const safe={id:u.id,name:u.name,email:u.email,phone:u.phone,is_guest:u.is_guest,is_admin:u.is_admin};setCookie(res,tokenFor(safe));res.json({user:safe});
});
app.post("/api/auth/guest",(req,res)=>{
  const email=`guest_${Date.now()}@guest.local`;const info=db.prepare("INSERT INTO users(name,email,phone,is_guest,created_at) VALUES(?,?,?,?,?)").run("Guest User",email,"",1,new Date().toISOString());
  const u=db.prepare("SELECT id,name,email,phone,is_guest,is_admin FROM users WHERE id=?").get(info.lastInsertRowid);setCookie(res,tokenFor(u));res.json({user:u});
});
app.post("/api/auth/logout",(req,res)=>{clearCookie(res);res.json({ok:true})});
app.get("/api/auth/me",(req,res)=>{try{const p=jwt.verify(parseCookies(req).hotel_token,JWT_SECRET);const u=db.prepare("SELECT id,name,email,phone,is_guest,is_admin FROM users WHERE id=?").get(p.id);return res.json({user:u||null})}catch{return res.json({user:null})}});

app.get("/api/rooms",(req,res)=>{
  const {search="",type="",checkIn="",checkOut=""}=req.query;
  let rooms=db.prepare("SELECT * FROM rooms WHERE (?='' OR name LIKE '%'||?||'%' OR number LIKE '%'||?||'%') AND (?='' OR type=?) ORDER BY number").all(search,search,search,type,type);
  if(checkIn&&checkOut){
    rooms=rooms.filter(r=>!db.prepare(`SELECT 1 FROM bookings WHERE room_id=? AND status='confirmed' AND check_in < ? AND check_out > ?`).get(r.id,checkOut,checkIn));
  }
  res.json({rooms});
});
app.get("/api/foods",(req,res)=>{
  const {search="",category=""}=req.query;
  const foods=db.prepare("SELECT * FROM foods WHERE (?='' OR name LIKE '%'||?||'%' OR description LIKE '%'||?||'%') AND (?='' OR category=?) ORDER BY id").all(search,search,search,category,category);
  res.json({foods});
});
app.post("/api/bookings",auth,(req,res)=>{
  const {roomId,guestName,guestPhone,email,guests,checkIn,checkOut,notes,paymentMethod,total}=req.body||{};
  const room=db.prepare("SELECT * FROM rooms WHERE id=?").get(roomId);
  if(!room)return res.status(404).json({error:"Room not found"});
  if(!guestName||!guestPhone||!email||!checkIn||!checkOut||new Date(checkOut)<=new Date(checkIn))return res.status(400).json({error:"Invalid booking details"});
  const clash=db.prepare(`SELECT 1 FROM bookings WHERE room_id=? AND status='confirmed' AND check_in < ? AND check_out > ?`).get(roomId,checkOut,checkIn);
  if(clash)return res.status(409).json({error:"Room is not available for those dates."});
  const nights=Math.max(1,Math.ceil((new Date(checkOut)-new Date(checkIn))/86400000));
  const finalTotal=nights*room.price;
  const bookingCode=code("RG");
  const info=db.prepare(`INSERT INTO bookings(booking_code,user_id,room_id,guest_name,guest_phone,email,guests,check_in,check_out,notes,payment_method,total,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(bookingCode,req.user.id,roomId,guestName,guestPhone,email,Number(guests)||1,checkIn,checkOut,notes||"",paymentMethod||"cash",finalTotal,new Date().toISOString());
  const booking=db.prepare(`SELECT b.*,r.name roomName,r.number roomNumber FROM bookings b JOIN rooms r ON r.id=b.room_id WHERE b.id=?`).get(info.lastInsertRowid);
  res.json({booking});
});
app.get("/api/cart",auth,(req,res)=>{
  const cart=db.prepare(`SELECT c.food_id foodId,c.quantity,f.name,f.price,f.image,f.category FROM cart_items c JOIN foods f ON f.id=c.food_id WHERE c.user_id=? ORDER BY c.id`).all(req.user.id);
  const total=cart.reduce((s,x)=>s+x.price*x.quantity,0);res.json({cart,total});
});
app.post("/api/cart",auth,(req,res)=>{
  const food=db.prepare("SELECT id FROM foods WHERE id=?").get(req.body.foodId);if(!food)return res.status(404).json({error:"Food not found"});
  const q=Number(req.body.quantity)||0;
  if(q<=0)db.prepare("DELETE FROM cart_items WHERE user_id=? AND food_id=?").run(req.user.id,food.id);
  else db.prepare(`INSERT INTO cart_items(user_id,food_id,quantity) VALUES(?,?,?) ON CONFLICT(user_id,food_id) DO UPDATE SET quantity=excluded.quantity`).run(req.user.id,food.id,q);
  res.json({ok:true});
});
app.post("/api/orders",auth,(req,res)=>{
  const {name,phone,room,notes}=req.body||{};
  const items=db.prepare(`SELECT c.food_id foodId,c.quantity,f.name,f.price FROM cart_items c JOIN foods f ON f.id=c.food_id WHERE c.user_id=?`).all(req.user.id);
  if(!items.length)return res.status(400).json({error:"Cart is empty"});
  const total=items.reduce((s,x)=>s+x.price*x.quantity,0),orderCode=code("FOOD");
  const tx=db.transaction(()=>{
    const info=db.prepare("INSERT INTO food_orders(order_code,user_id,name,phone,room,notes,total,created_at) VALUES(?,?,?,?,?,?,?,?)").run(orderCode,req.user.id,name,phone,room||"",notes||"",total,new Date().toISOString());
    const ins=db.prepare("INSERT INTO food_order_items(order_id,food_id,name,price,quantity) VALUES(?,?,?,?,?)");
    items.forEach(i=>ins.run(info.lastInsertRowid,i.foodId,i.name,i.price,i.quantity));
    db.prepare("DELETE FROM cart_items WHERE user_id=?").run(req.user.id);
    return info.lastInsertRowid;
  });
  const id=tx();const order=db.prepare("SELECT * FROM food_orders WHERE id=?").get(id);order.items=items;res.json({order});
});
app.post("/api/services",auth,(req,res)=>{
  const requestCode=code("SRV");const info=db.prepare("INSERT INTO service_requests(request_code,user_id,service,details,created_at) VALUES(?,?,?,?,?)").run(requestCode,req.user.id,req.body.service,req.body.details||"",new Date().toISOString());
  res.json({request:{requestCode,id:info.lastInsertRowid}});
});
const reviews=[
  {name:"Amit",rating:5,text:"Beautiful rooms, friendly staff and smooth service."},
  {name:"Priya",rating:5,text:"Food ordering was convenient and the stay was comfortable."},
  {name:"Rahul",rating:4,text:"Clean property with helpful guest services."},
  {name:"Sneha",rating:5,text:"Loved the atmosphere and breakfast."},
  {name:"Arjun",rating:4,text:"Good rooms and quick response from the service team."},
  {name:"Meera",rating:5,text:"A comfortable hotel for family travel."}
];
app.get("/api/reviews",(req,res)=>res.json({reviews}));
app.get("/api/dashboard",auth,(req,res)=>{
  const bookings=db.prepare(`SELECT b.*,r.name roomName,r.number roomNumber FROM bookings b JOIN rooms r ON r.id=b.room_id WHERE b.user_id=? ORDER BY b.id DESC`).all(req.user.id);
  const orders=db.prepare("SELECT * FROM food_orders WHERE user_id=? ORDER BY id DESC").all(req.user.id);
  const services=db.prepare("SELECT * FROM service_requests WHERE user_id=? ORDER BY id DESC").all(req.user.id);
  const foodSpent=orders.reduce((s,x)=>s+x.total,0);
  res.json({bookings,orders,services,stats:{bookings:bookings.length,foodOrders:orders.length,services:services.length,foodSpent}});
});
app.get("/api/admin/summary",admin,(req,res)=>{
  const counts={users:db.prepare("SELECT COUNT(*) c FROM users WHERE is_admin=0").get().c,bookings:db.prepare("SELECT COUNT(*) c FROM bookings").get().c,foodOrders:db.prepare("SELECT COUNT(*) c FROM food_orders").get().c,services:db.prepare("SELECT COUNT(*) c FROM service_requests").get().c};
  res.json({counts});
});
app.get("/api/admin/bookings",admin,(req,res)=>res.json({bookings:db.prepare(`SELECT b.*,r.name roomName,r.number roomNumber FROM bookings b JOIN rooms r ON r.id=b.room_id ORDER BY b.id DESC`).all()}));
app.get("/api/admin/orders",admin,(req,res)=>res.json({orders:db.prepare("SELECT * FROM food_orders ORDER BY id DESC").all()}));
app.get("/api/admin/services",admin,(req,res)=>res.json({services:db.prepare("SELECT * FROM service_requests ORDER BY id DESC").all()}));

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`Royal Grand Hotel running on http://localhost:${PORT}`));
