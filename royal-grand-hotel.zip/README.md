# Royal Grand Hotel - Full Website

## Includes
- Login / Register / Guest Login
- Home with About, hotel photos and reviews
- 56 seeded rooms with different image URLs
- Room search/filter and date availability
- Guest details and separate payment section
- Booking confirmation
- 400 seeded food items with food-specific image query URLs
- Food search/filter, cart, quantity, total and order flow
- WhatsApp links to 7894410792
- Room Service, Airport Pickup, Laundry, Housekeeping, Taxi/Cab, Extra Bed, Event/Banquet, Breakfast, Luggage Assistance
- Facilities, Gallery, Reviews, Google Maps, Call
- User dashboard
- SQLite database
- Password hashing
- JWT httpOnly cookie authentication
- Basic admin API

## Run locally

1. Install Node.js 18+.
2. Open terminal in this folder.
3. Run:
   npm install
4. Copy `.env.example` to `.env` and change JWT_SECRET and admin password.
5. Run:
   npm start
6. Open:
   http://localhost:3000

The SQLite database `hotel.db` is created automatically and 56 rooms + 400 food items are seeded on first run.

## Important production notes
- Change ADMIN_PASSWORD and JWT_SECRET.
- Use HTTPS.
- Use a managed database or persistent disk if your hosting provider has an ephemeral filesystem.
- The payment screen is UI only. Connect a real PCI-compliant payment provider before taking online payments.
- Image URLs currently use LoremFlickr query/lock URLs so the demo has different images without storing hundreds of image files. For a production hotel site, replace them with your own licensed hotel/food images.
- WhatsApp opens a chat to +91 7894410792. It does not silently send messages; the user confirms/sends in WhatsApp.
